GITHUB PAGES SETUP
1. Create a free GitHub account.
2. Create a new public repository named aura-aarin-invitation.
3. Upload index.html from this folder.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch: main and folder: /(root), then Save.
7. Your public link will be:
   https://YOUR-USERNAME.github.io/aura-aarin-invitation/

FORM SUBMIT
The first RSVP submission sends a confirmation email to rajinvincinble@gmail.com.
Open that email and confirm once. Future RSVPs will then arrive automatically.
